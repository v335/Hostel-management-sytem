<?php include ('connect.php');

                            if (isset($_POST['submit'])) {

                                
                                $loan_id = $_POST['loan_id'];
                                $id_no = $_POST['id_no'];
                                 $income_range= $_POST['income_range'];
					            $loan_come_from = $_POST['loan_come_from'];
								$group_id = $_POST['group_id'];
                                $loan_amount= $_POST['loan_amount'];
								
										$query = mysql_query("select * from loan where loan_id= '$loan_id'") or die (mysql_error());
										$count = mysql_num_rows($query);

									if ($count  > 0){ 
									?>
										<script>
											alert("Loan Id Exists in the System");
										</script>
									<?php
										}
										else{
									 mysql_query("insert into loan (id_no,income_range,loan_come_from,group_id,loan_amount) values('$id_no','$income_range','$loan_come_from','$group_id','$loan_amount')") or die(mysql_error());
									?>
									<script>
										alert('Loan Successfully Applied');
										header('location:client_portal.php');
									
									</script>
									<?php }} ?>	

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>loan</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="lds-ellipsis">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">
        <!-- Top Header Area -->
        <div class="top-header-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12 d-flex justify-content-between">
                        <!-- Logo Area -->
                        <div class="logo">
                        </div>

                        <!-- Top Contact Info -->
                        <div class="top-contact-info d-flex align-items-center">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navbar Area -->
        <div class="credit-main-menu" id="sticker">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="creditNav">

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="client_portal.php">Home</a></li>
                                    <li><a href="profile.php">Profile</a></li>
                                     <li><a href="loan2.php">Apply Loan</a></li>
									<li><a href="pay2.php">Pay Loan</a></li>
									 <li><a href="save2.php">My Savings</a></li>
                                    <li><a href="statement.php">Loan Statement</a></li>
						            <li><a href="payment_statement.php">Payment Statement</a></li>
                                    <li><a href="logout.php">Logout</a></li>
                                        </div>
                                    </li>
                                 
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>

                        <!-- Contact -->
                        <div class="contact">
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>





    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title></title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<!-- main header end -->

    <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                          
                                        </div>
                                        <div class="modal-body">
                              <form action="loan2.php" method="post" >
                                
                                <hr>
                                <div class="alert alert-info"><strong><center>Apply for a loan</center></strong></div>
                                <hr>
								
								
                               <div class="control-group">
                                    <label class="control-label" for="inputPassword">Id no:</label>
                                    <div class="controls">
                                        <input type="number" name="id_no" required maxlength="8" class = "form-control"  placeholder="id no">
                                    </div>
                                </div>
								
						<div class="row" style="margin-top:10px">
		<div class="col-sm-4">Loan Category</div>
		<div class="col-sm-5">
		<select name="group_id" class="form-control" required>
			<option value="">Select Loan Category</option>
			<option value="6" >Personal </option>
			<option value="5" >Group</option>
		</select>
		</div>
	</div>
			<div class="row" style="margin-top:10px">
		<div class="col-sm-4">Income Source</div>
		<div class="col-sm-5">
		<select name="loan_come_from" class="form-control" required>
			<option value="">Select Income Category</option>
			<option>Employed </option>
			<option>Self-Employed</option>
		    <option>Council </option>
			<option>Other</option>
		</select>
		</div>
	</div>
		<div class="row" style="margin-top:10px">
		<div class="col-sm-4">Income Range</div>
		<div class="col-sm-5">
		<select name="income_range" class="form-control" required>
			<option value="">Select Income Range</option>
			<option>0-15000</option>
			<option>15000-25000</option>
			<option>25000-40000</option>
			<option>40000-100000</option>
			<option>Above 100000</option>
		</select>
		</div>
	</div>
	
                                <div class="control-group">
                                    <label class="control-label" for="inputPassword">Amount:</label>
                                    <div class="controls">
                                        <input type="number"  required name="loan_amount" required class = "form-control" placeholder="amount">
                                    </div>
                                </div>
                               
			
								

								<div class = "modal-footer">
											 <button name = "submit" class="btn btn-primary">Save</button>
											<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                           

								</div>
							
									   </div>
                                     
                                          
                                      
                                    </div>
									
									  </form>  

                          									  
									  
									  
									  
                                </div>
								   </div>


                           <div class="panel-heading">
 
<body>
<div>
							<script src="css/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="css/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="css/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="css/sb-admin-2.js"></script>

</body>

   
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>
