<?php include ('connect.php');

                            if (isset($_POST['submit'])) {

                                $code = $_POST['code'];
                                $id_no = $_POST['id_no'];
                                 $room_type= $_POST['room_type'];
					            $roomNo = $_POST['roomNo'];
								
										$query = mysql_query("select * from bookings where code= '$code'") or die (mysql_error());
										$count = mysql_num_rows($query);

									if ($count  > 0){ 
									?>
										<script>
											alert("Booking Code Already Taken");
                                        </script>
                                    

                                   <?php
                                
										}
										else{
									 mysql_query("insert into bookings (id_no,room_type,roomNo,code) values('$id_no','$room_type','$roomNo','$code')") or die(mysql_error());
									?>
									<script type="text/javascript">  
										alert('Room Booking Successful procede to payment');  
                                        // precede to payment after booking 
                                        window.location.href = "pay2.php";
                                          </script>
									<?php }} ?>	
<?php
if (!isset($_SESSION)) {
  session_start();
}
//database connection
$hostname_conn = "localhost";
$database_conn = "hms4";
$username_conn = "root";
$password_conn = "";
$conn = mysql_connect($hostname_conn, $username_conn, $password_conn) or trigger_error(mysql_error(),E_USER_ERROR); 


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Hostel</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="lds-ellipsis">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">
        <!-- Top Header Area -->
        <div class="top-header-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12 d-flex justify-content-between">
                        <!-- Logo Area -->
                        <div class="logo">
                        </div>

                        <!-- Top Contact Info -->
                        <div class="top-contact-info d-flex align-items-center">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navbar Area -->
        <div class="credit-main-menu" id="sticker">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="creditNav">

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                   <li><a href="client_portal.php">Home</a></li>
                                    <li><a href="profile.php">Profile</a></li>
									<li><a href="save.php">Book Hostel</a></li>
									<li><a href="pay2.php">Pay Hostel</a></li>
                                    <li><a href="statement.php">Booking Statement</a></li>
									 <li><a href="payment_statement.php">Payment Statement</a></li>
                                    <li><a href="logout.php">Logout</a></li>
                                        </div>
                                    </li>
                                 
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>

                        <!-- Contact -->
                        <div class="contact">
                            <a href="#"><img src="img/core-img/call2.png" alt=""> +254718</a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>





    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Hostel !</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<!-- main header end -->

    <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                          
                                        </div>
                                        <div class="modal-body">
                              <form action="save.php" method="post" >
                                
                                <hr>
                                <div class="alert alert-info"><strong><center>Book Hostel</center></strong></div>
                                <hr>
								
								
                               <div class="control-group">
                                    <label class="control-label" for="inputPassword">Id no:</label>
                                    <div class="controls">
                                        <input type="number" name="id_no" required maxlength="8" class = "form-control"  placeholder="id no">
                                    </div>
                                </div>
								 <div class="control-group">
                                    <label class="control-label" for="inputPassword">Booking Code:</label>
                                    <div class="controls">
                                        <input type="text" name="code" required  class = "form-control"  placeholder="input your own unique booking code">
                                    </div>
                                </div>
								  <div class="control-group">
                                    <label class="control-label" for="inputPassword">Email:</label>
                                    <div class="controls">
                                        <input type="text"  required name="email" required class = "form-control" placeholder="Email">
                                    </div>
                                </div>
								 <div class="control-group">
		<div class="col-sm-4">Room Type</div>
<select name="room_type"  value="<?=$room_type;?>">
				<?php 
		include "connect.php";
  $query =mysql_query("select * from room_type  ");
						echo "<option>select Room Type</option>";
					while($rs=mysql_fetch_array($query)){
						echo "<option>".$rs['room_type']."</option>";
					}
				?>
		</select></div>
	<div class="col-sm-4">Select Room</div>
<select name="roomNo"  value="<?=$roomNo;?>">
				<?php 
		include "connect.php";
  $query =mysql_query("select * from rooms  ");
						echo "<option>select Room</option>";
					while($rs=mysql_fetch_array($query)){
						echo "<option>".$rs['roomNo']."</option>";
					}
				?>
		</select></div>	
                               
                               
			
								

								<div class = "modal-footer">
                                             <button name = "submit" class="btn btn-primary">Book Room</button>
                                                   <script>"text/javascript">    
                                                function Redirect() {
                                                  window.location = "../pay2.php";
                                                           }  
                                                        </script>
                                    </form>
											<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                           

								</div>
							
									   </div>
                                     
                                          
                                      
                                    </div>
									
									  </form>  

                          									  
									  
									  
									  
                                </div>
								   </div>


                           <div class="panel-heading">
   
<div>
							<script src="css/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="css/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="css/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="css/sb-admin-2.js"></script>

</body>

   
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>