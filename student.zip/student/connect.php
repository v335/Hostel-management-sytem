<?php
mysql_select_db('hms4',  mysql_connect('localhost','root',''))or die(mysql_error());
?>
