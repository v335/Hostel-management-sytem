<?PHP
require_once("connect.php");
$sql="insert into message(name, email, subject, message) values('$_POST[name]','$_POST[email]','$_POST[subject]','$_POST[message]')";
mysql_query($sql);
{
		?> 
 <script>
  alert('message sent Successfully');
  window.location='contact.php';
 </script>
 <?php
	}
?>